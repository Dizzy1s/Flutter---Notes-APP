package com.example.firebase_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
